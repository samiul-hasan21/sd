document.addEventListener('DOMContentLoaded', () => {
    const inventoryForm = document.getElementById('inventoryForm');
    const salesForm = document.getElementById('salesForm');
    const salesReportForm = document.getElementById('salesReportForm');
    const userSettingsForm = document.getElementById('userSettingsForm');
    const systemSettingsForm = document.getElementById('systemSettingsForm');

    if (inventoryForm) {
        inventoryForm.addEventListener('submit', (event) => {
            event.preventDefault();
            alert('New inventory item added!');
        });
    }

    if (salesForm) {
        salesForm.addEventListener('submit', (event) => {
            event.preventDefault();
            alert('New sale recorded!');
        });
    }

    if (salesReportForm) {
        salesReportForm.addEventListener('submit', (event) => {
            event.preventDefault();
            alert('Sales report generated!');
        });
    }

    if (userSettingsForm) {
        userSettingsForm.addEventListener('submit', (event) => {
            event.preventDefault();
            alert('User settings saved!');
        });
    }

    if (systemSettingsForm) {
        systemSettingsForm.addEventListener('submit', (event) => {
            event.preventDefault();
            alert('System settings saved!');
        });
    }

    const salesChartElement = document.getElementById('salesChart');
    if (salesChartElement) {
        const ctx = salesChartElement.getContext('2d');
        const salesChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June'],
                datasets: [{
                    label: 'Sales',
                    data: [1200, 1900, 3000, 5000, 2300, 4000],
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
});
